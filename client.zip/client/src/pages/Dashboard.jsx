import { useState, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import VitalsChart from '../components/VitalsChart';

const Dashboard = () => {
    const { user, logout } = useAuth();
    const [activeTab, setActiveTab] = useState('vitals');
    const [vitals, setVitals] = useState([]);
    const [reports, setReports] = useState([]);
    const [shares, setShares] = useState([]);
    const [loading, setLoading] = useState(true);

    // Vitals Form State
    const [newVital, setNewVital] = useState({ type: 'BP', value: '', unit: '' });

    // Report Upload State
    const [uploadFile, setUploadFile] = useState(null);
    const [reportForm, setReportForm] = useState({ title: '', category: 'Blood Test', metadata: '' });

    // Share Form State
    const [shareEmail, setShareEmail] = useState('');

    const fetchData = async () => {
        try {
            const [vitalsRes, reportsRes, sharesRes] = await Promise.all([
                api.get('/api/vitals'),
                api.get('/api/reports'),
                api.get('/api/share')
            ]);
            setVitals(vitalsRes.data);
            setReports(reportsRes.data);
            setShares(sharesRes.data);
            setLoading(false);
        } catch (error) {
            console.error("Error fetching data", error);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleAddVital = async (e) => {
        e.preventDefault();
        try {
            await api.post('/api/vitals', newVital);
            setNewVital({ type: 'BP', value: '', unit: '' });
            fetchData(); // Refresh
            alert('Vital added');
        } catch (error) {
            alert('Error adding vital');
        }
    };

    const handleUploadReport = async (e) => {
        e.preventDefault();
        if (!uploadFile) return;
        const formData = new FormData();
        formData.append('file', uploadFile);
        formData.append('title', reportForm.title);
        formData.append('category', reportForm.category);
        formData.append('metadata', reportForm.metadata); // Optional JSON string

        try {
            await api.post('/api/reports', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            setReportForm({ title: '', category: 'Blood Test', metadata: '' });
            setUploadFile(null);
            fetchData();
            alert('Report uploaded');
        } catch (error) {
            alert('Error uploading report');
        }
    };

    const handleShare = async (e) => {
        e.preventDefault();
        try {
            await api.post('/api/share', {
                viewerEmail: shareEmail,
                resourceType: 'ALL' // Simple sharing for now
            });
            setShareEmail('');
            fetchData();
            alert('Access granted');
        } catch (error) {
            alert(error.response?.data?.message || 'Error sharing');
        }
    };

    const handleRevoke = async (id) => {
        try {
            await api.delete(`/api/share/${id}`);
            fetchData();
        } catch (error) {
            alert('Error revoking access');
        }
    };

    const handleDownload = async (id, filename) => {
        try {
            const response = await api.get(`/api/reports/${id}/file`, {
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', filename.split('/').pop()); // Extract filename
            document.body.appendChild(link);
            link.click();
        } catch (error) {
            alert('Error downloading file');
        }
    };

    if (loading) return <div className="p-4">Loading...</div>;

    const handleDeleteVital = async (id) => {
        if (!window.confirm("Are you sure you want to delete this log?")) return;
        try {
            await api.delete(`/api/vitals/${id}`);
            setVitals(vitals.filter(v => v.id !== id));
        } catch (error) {
            console.error("Error deleting vital", error);
            alert(error.response?.data?.message || "Failed to delete log");
        }
    };

    const handleDeleteReport = async (id) => {
        if (!window.confirm("Are you sure you want to delete this report?")) return;
        try {
            await api.delete(`/api/reports/${id}`);
            setReports(reports.filter(r => r.id !== id));
        } catch (error) {
            console.error("Error deleting report", error);
            alert(error.response?.data?.message || "Failed to delete report");
        }
    };

    return (
        <div className="container" style={{ paddingBottom: '2rem' }}>
            <header className="flex justify-between items-center py-4 mb-4 border-b">
                <div>
                    <h1 className="text-xl">Welcome, {user?.username}</h1>
                </div>
                <button
                    onClick={logout}
                    style={{
                        background: 'none',
                        border: 'none',
                        padding: '0',
                        color: 'var(--text-main)',
                        textDecoration: 'underline',
                        cursor: 'pointer',
                        fontSize: '1rem'
                    }}
                    onMouseOver={(e) => e.target.style.color = 'var(--primary)'}
                    onMouseOut={(e) => e.target.style.color = 'var(--text-main)'}
                >
                    Logout
                </button>
            </header>

            {/* Tabs */}
            <div className="flex gap-4 mb-6 border-b">
                {['vitals', 'overview', 'reports', 'sharing'].map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        style={{
                            padding: '0.5rem 1rem',
                            borderBottom: activeTab === tab ? '2px solid var(--primary)' : 'none',
                            fontWeight: activeTab === tab ? 'bold' : 'normal',
                            color: activeTab === tab ? 'var(--primary)' : 'inherit'
                        }}
                    >
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                ))}
            </div>

            {activeTab === 'overview' && (
                <div className="grid gap-4">
                    <div className="card">
                        <h3 className="text-xl mb-4">Quick Vitals Overview</h3>
                        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
                            <VitalsChart data={vitals} type="BP" />
                            <VitalsChart data={vitals} type="HeartRate" />
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'vitals' && (
                <div className="grid gap-4">
                    <div className="card">
                        <h3 className="text-xl mb-6">Add Vital</h3>
                        <form onSubmit={handleAddVital} className="flex gap-4 items-end flex-wrap">
                            <div style={{ flex: '0 0 auto' }}>
                                <select className="input" style={{ width: '140px', padding: '0.4rem' }} value={newVital.type} onChange={e => setNewVital({ ...newVital, type: e.target.value, value: '' })}>
                                    <option value="BP">BP</option>
                                    <option value="HeartRate">Heart Rate</option>
                                    <option value="Sugar">Blood Sugar</option>
                                    <option value="Weight">Weight</option>
                                </select>
                            </div>

                            {newVital.type === 'BP' ? (
                                <div className="flex gap-2 items-end">
                                    <div className="flex items-center gap-2">
                                        <div>
                                            <label className="text-sm block mb-1">Systolic</label>
                                            <input
                                                className="input"
                                                type="number"
                                                placeholder="120"
                                                style={{ width: '70px', padding: '0.4rem' }}
                                                min="0"
                                                value={newVital.value.split('/')[0] || ''}
                                                onChange={e => {
                                                    const sys = e.target.value;
                                                    const dia = newVital.value.split('/')[1] || '';
                                                    setNewVital({ ...newVital, value: `${sys}/${dia}` })
                                                }}
                                                required
                                            />
                                        </div>
                                    </div>
                                    <span style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>/</span>
                                    <div className="flex items-center gap-2">
                                        <div>
                                            <label className="text-sm block mb-1">Diastolic</label>
                                            <input
                                                className="input"
                                                type="number"
                                                placeholder="80"
                                                style={{ width: '70px', padding: '0.4rem' }}
                                                min="0"
                                                value={newVital.value.split('/')[1] || ''}
                                                onChange={e => {
                                                    const sys = newVital.value.split('/')[0] || '';
                                                    const dia = e.target.value;
                                                    setNewVital({ ...newVital, value: `${sys}/${dia}` })
                                                }}
                                                required
                                            />
                                        </div>
                                        <span className="text-sm text-muted" style={{ marginBottom: '0.5rem' }}>mmHg</span>
                                    </div>
                                </div>
                            ) : (
                                <div style={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                    <input
                                        className="input"
                                        style={{ width: '120px', padding: '0.4rem' }}
                                        type="number"
                                        placeholder="e.g. 98"
                                        min="0"
                                        value={newVital.value}
                                        onChange={e => setNewVital({ ...newVital, value: e.target.value })}
                                        required
                                    />
                                    <span className="text-sm text-muted">
                                        {newVital.type === 'HeartRate' ? 'bpm' :
                                            newVital.type === 'Sugar' ? 'mg/dL' :
                                                newVital.type === 'Weight' ? 'kg' : ''}
                                    </span>
                                </div>
                            )}

                            <div style={{ flex: '0 0 auto' }}>
                                <button type="submit" className="btn btn-primary" style={{ minWidth: '80px', padding: '0.4rem 1rem' }}>Add Log</button>
                            </div>
                        </form>
                    </div>

                    <div className="card">
                        <h3 className="text-xl mb-4">History</h3>
                        <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                                    <th className="p-2">Date</th>
                                    <th className="p-2">Type</th>
                                    <th className="p-2">Value</th>
                                    <th className="p-2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {vitals.map(v => (
                                    <tr key={v.id} style={{ borderBottom: '1px solid var(--border)' }}>
                                        <td className="p-2">{new Date(v.date).toLocaleDateString()}</td>
                                        <td className="p-2">{v.type}</td>
                                        <td className="p-2">{v.value} {v.unit}</td>
                                        <td className="p-2">
                                            <button
                                                onClick={() => handleDeleteVital(v.id)}
                                                style={{
                                                    background: 'none',
                                                    border: 'none',
                                                    padding: '0',
                                                    color: 'var(--danger)',
                                                    fontSize: '0.875rem',
                                                    cursor: 'pointer',
                                                    textDecoration: 'underline'
                                                }}
                                            >
                                                Delete
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'reports' && (
                <div className="grid gap-4">
                    <div className="card">
                        <h3 className="text-xl mb-6">Upload Report</h3>
                        <form onSubmit={handleUploadReport} className="flex gap-4 items-end flex-wrap">
                            <div style={{ flex: '0 0 auto' }}>
                                <label className="text-sm block mb-1">Title</label>
                                <input
                                    className="input"
                                    placeholder="Title"
                                    style={{ width: '150px', padding: '0.4rem' }}
                                    value={reportForm.title}
                                    onChange={e => setReportForm({ ...reportForm, title: e.target.value })}
                                    required
                                />
                            </div>
                            <div style={{ flex: '0 0 auto' }}>
                                <label className="text-sm block mb-1">Category</label>
                                <select
                                    className="input"
                                    style={{ width: '120px', padding: '0.4rem' }}
                                    value={reportForm.category}
                                    onChange={e => setReportForm({ ...reportForm, category: e.target.value })}
                                >
                                    <option>Blood Test</option>
                                    <option>X-Ray</option>
                                    <option>Prescription</option>
                                    <option>MRI</option>
                                </select>
                            </div>
                            <div style={{ flex: '0 0 auto' }}>
                                <label className="text-sm block mb-1">File</label>
                                <input
                                    type="file"
                                    className="input"
                                    style={{ padding: '0.4rem', fontSize: '0.875rem', width: '200px' }}
                                    onChange={e => setUploadFile(e.target.files[0])}
                                    required
                                />
                            </div>
                            <div style={{ flex: '0 0 auto' }}>
                                <button type="submit" className="btn btn-primary" style={{ padding: '0.4rem 1rem', minWidth: '80px' }}>Upload</button>
                            </div>
                        </form>
                    </div>

                    <div className="card">
                        <h3 className="text-xl mb-4">History</h3>
                        <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                                    <th className="p-2">Title</th>
                                    <th className="p-2">Category</th>
                                    <th className="p-2">Date</th>
                                    <th className="p-2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reports.length === 0 ? (
                                    <tr>
                                        <td colSpan="4" className="p-4 text-center text-muted">No reports found. Upload one above.</td>
                                    </tr>
                                ) : reports.map(r => (
                                    <tr key={r.id} style={{ borderBottom: '1px solid var(--border)' }}>
                                        <td className="p-2">
                                            {r.title}
                                            {r.User && r.User.email !== user.email && (
                                                <span style={{ fontSize: '0.75rem', marginLeft: '0.5rem', background: '#e0f2fe', color: '#0369a1', padding: '0.1rem 0.5rem', borderRadius: '4px' }}>
                                                    Shared by {r.User.username}
                                                </span>
                                            )}
                                        </td>
                                        <td className="p-2">{r.category}</td>
                                        <td className="p-2">{new Date(r.upload_date).toLocaleDateString()}</td>
                                        <td className="p-2 flex gap-4 items-center">
                                            <button
                                                onClick={() => handleDownload(r.id, r.file_path)}
                                                style={{
                                                    background: 'none',
                                                    border: 'none',
                                                    padding: '0',
                                                    color: 'var(--primary)',
                                                    fontSize: '0.9rem',
                                                    cursor: 'pointer',
                                                    textDecoration: 'underline',
                                                    fontWeight: '500',
                                                    whiteSpace: 'nowrap'
                                                }}
                                            >
                                                Download
                                            </button>
                                            {(!r.User || r.User.email === user.email) && (
                                                <button
                                                    onClick={() => handleDeleteReport(r.id)}
                                                    style={{
                                                        background: 'none',
                                                        border: 'none',
                                                        padding: '0',
                                                        color: 'var(--danger)',
                                                        fontSize: '0.9rem',
                                                        cursor: 'pointer',
                                                        textDecoration: 'underline',
                                                        whiteSpace: 'nowrap'
                                                    }}
                                                >
                                                    Delete
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'sharing' && (
                <div className="grid gap-4">
                    <div className="card">
                        <h3 className="text-xl mb-4">Grant Access</h3>
                        <p className="text-muted mb-4">Share all your reports and vitals with a family member or doctor.</p>
                        <form onSubmit={handleShare} className="flex gap-4 items-end flex-wrap">
                            <div style={{ flex: '0 0 auto' }}>
                                <label className="text-sm block mb-1">Doctor/Family Email</label>
                                <input
                                    type="email"
                                    className="input"
                                    placeholder="email@example.com"
                                    style={{ width: '250px', padding: '0.4rem' }}
                                    value={shareEmail}
                                    onChange={e => setShareEmail(e.target.value)}
                                    required
                                />
                            </div>
                            <div style={{ flex: '0 0 auto' }}>
                                <button type="submit" className="btn btn-primary" style={{ padding: '0.4rem 1rem', minWidth: '100px' }}>Grant Access</button>
                            </div>
                        </form>
                    </div>

                    <div className="card">
                        <h3 className="text-xl mb-4">Active Shares</h3>
                        {shares.length === 0 ? <p>You haven't shared access with anyone.</p> : (
                            <ul style={{ listStyle: 'none' }}>
                                {shares.map(s => (
                                    <li key={s.id} className="flex justify-between items-center p-2 border-b">
                                        <span>{s.viewer_email} ({s.resource_type})</span>
                                        <button onClick={() => handleRevoke(s.id)} style={{ color: 'var(--danger)' }}>Revoke</button>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default Dashboard;
