import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';

const PrivateRoute = ({ children }) => {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
          <nav style={{ background: 'var(--surface)', padding: '1rem', borderBottom: '1px solid var(--border)' }}>
            <div className="container flex items-center" style={{ justifyContent: 'center' }}>
              <h2 className="text-xl" style={{ color: 'var(--primary)', fontWeight: 'bold', fontSize: '2rem' }}>Health Wallet</h2>
              {/* Navigation items could go here if managed inside specific components or a layout */}
            </div>
          </nav>
          <main style={{ flex: 1 }}>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route
                path="/*"
                element={
                  <PrivateRoute>
                    <Dashboard />
                  </PrivateRoute>
                }
              />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
