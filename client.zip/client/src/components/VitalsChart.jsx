import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const VitalsChart = ({ data, type }) => {
    // Filter data by type
    const filteredData = data.filter(d => d.type === type).reverse(); // Reverse for chronological order if needed

    // If BP, we might have 120/80 string. Need to parse.
    // Helper to parse value
    const parseData = (d) => {
        if (d.type === 'BP') {
            const [sys, dia] = d.value.split('/');
            return { ...d, sys: parseInt(sys), dia: parseInt(dia), dateFormatted: new Date(d.date).toLocaleDateString() };
        }
        return { ...d, val: parseFloat(d.value), dateFormatted: new Date(d.date).toLocaleDateString() };
    };

    const chartData = filteredData.map(parseData);

    if (type === 'BP') {
        return (
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="dateFormatted" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sys" stroke="#ef4444" name="Systolic" />
                    <Line type="monotone" dataKey="dia" stroke="#3b82f6" name="Diastolic" />
                </LineChart>
            </ResponsiveContainer>
        );
    }

    return (
        <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="dateFormatted" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="val" stroke="#10b981" name={type} />
            </LineChart>
        </ResponsiveContainer>
    );
};

export default VitalsChart;
