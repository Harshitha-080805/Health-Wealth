const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { sequelize } = require('./models');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Routes
const authRoutes = require('./routes/authRoutes');
const vitalRoutes = require('./routes/vitalRoutes');
const reportRoutes = require('./routes/reportRoutes');
const shareRoutes = require('./routes/shareRoutes');

app.use('/api/auth', authRoutes);
app.use('/api/vitals', vitalRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/share', shareRoutes);

// Test Route
app.get('/', (req, res) => {
    res.send('Digital Health Wallet API is running');
});

// Start Server
app.listen(PORT, async () => {
    console.log(`Server is running on port ${PORT}`);
    try {
        await sequelize.authenticate();
        console.log('Database connected!');
        // Sync models
        // await sequelize.sync({ alter: true }); 
        await sequelize.sync(); // Changed to simple sync to avoid backup table errors
        console.log('Database synced');
    } catch (error) {
        console.error('Unable to connect to the database:', error);
    }
});
