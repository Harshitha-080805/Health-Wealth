const { Vital } = require('../models');

exports.getVitals = async (req, res) => {
    try {
        const userId = req.user.id;
        const vitals = await Vital.findAll({ where: { user_id: userId }, order: [['date', 'DESC']] });
        res.json(vitals);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.addVital = async (req, res) => {
    try {
        const userId = req.user.id;
        const { type, value, unit, date } = req.body;

        const vital = await Vital.create({
            user_id: userId,
            type,
            value,
            unit,
            date: date || new Date(),
        });

        res.status(201).json(vital);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.deleteVital = async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;

        console.log(`[DEBUG] Attempting to delete vital. ID: ${id}, UserID: ${userId}`);
        const vital = await Vital.findOne({ where: { id, user_id: userId } });
        console.log(`[DEBUG] Vital found: ${vital ? 'Yes' : 'No'}`);

        if (!vital) return res.status(404).json({ message: "Vital not found" });

        await vital.destroy();
        res.json({ message: "Vital deleted" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
