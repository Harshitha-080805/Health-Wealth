const { Report, Share, User } = require('../models');
const { Op } = require('sequelize');
const fs = require('fs');
const path = require('path');

exports.uploadReport = async (req, res) => {
    try {
        const userId = req.user.id;
        const { title, category, metadata } = req.body;
        const file = req.file;

        if (!file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }

        const report = await Report.create({
            user_id: userId,
            title,
            category,
            file_path: file.path.replace(/\\/g, '/'), // Normalized path
            metadata: metadata ? JSON.parse(metadata) : null,
        });

        res.status(201).json(report);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getReports = async (req, res) => {
    try {
        const userId = req.user.id;
        const userEmail = req.user.email;

        // Find reports owned by user
        // OR reports shared with user (via email)

        // 1. Get IDs of owners who shared ALL with this user
        const sharedAll = await Share.findAll({
            where: {
                viewer_email: userEmail,
                resource_type: 'ALL'
            }
        });
        const ownerIds = sharedAll.map(s => s.owner_id);

        // 2. Get IDs of specific reports shared with this user
        const sharedReports = await Share.findAll({
            where: {
                viewer_email: userEmail,
                resource_type: 'REPORT'
            }
        });
        const reportIds = sharedReports.map(s => s.resource_id);

        // Query Reports
        const reports = await Report.findAll({
            where: {
                [Op.or]: [
                    { user_id: userId }, // Own reports
                    { user_id: { [Op.in]: ownerIds } }, // Shared via ALL
                    { id: { [Op.in]: reportIds } } // Shared specifically
                ]
            },
            include: [{ model: User, attributes: ['username', 'email'] }],
            order: [['upload_date', 'DESC']]
        });

        res.json(reports);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.downloadReport = async (req, res) => {
    try {
        const reportId = req.params.id;
        const userId = req.user.id;
        const userEmail = req.user.email;

        const report = await Report.findByPk(reportId);
        if (!report) return res.status(404).json({ message: "Report not found" });

        // Check access
        let hasAccess = false;
        if (report.user_id === userId) hasAccess = true;
        else {
            // Check share
            const share = await Share.findOne({
                where: {
                    viewer_email: userEmail,
                    [Op.or]: [
                        { resource_type: 'ALL', owner_id: report.user_id },
                        { resource_type: 'REPORT', resource_id: reportId }
                    ]
                }
            });
            if (share) hasAccess = true;
        }

        if (!hasAccess) return res.status(403).json({ message: "Access denied" });

        const filePath = path.resolve(report.file_path);
        if (fs.existsSync(filePath)) {
            res.download(filePath);
        } else {
            res.status(404).json({ message: "File not found on server" });
        }

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error" });
    }
};

exports.deleteReport = async (req, res) => {
    try {
        const userId = req.user.id;
        const reportId = req.params.id;

        const report = await Report.findOne({ where: { id: reportId, user_id: userId } });
        if (!report) return res.status(404).json({ message: "Report not found" });

        // Delete file from filesystem
        const filePath = path.resolve(report.file_path);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        await report.destroy();
        res.json({ message: "Report deleted" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error" });
    }
};
