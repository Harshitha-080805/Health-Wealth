const { Share, User } = require('../models');

exports.shareResource = async (req, res) => {
    try {
        const ownerId = req.user.id;
        const { viewerEmail, resourceType, resourceId } = req.body;

        if (viewerEmail === req.user.email) {
            return res.status(400).json({ message: "Cannot share with yourself" });
        }

        // Check if already shared
        const existing = await Share.findOne({
            where: {
                owner_id: ownerId,
                viewer_email: viewerEmail,
                resource_type: resourceType,
                resource_id: resourceId || null
            }
        });

        if (existing) {
            return res.status(400).json({ message: "Already shared" });
        }

        const share = await Share.create({
            owner_id: ownerId,
            viewer_email: viewerEmail,
            resource_type: resourceType,
            resource_id: resourceId || null,
            permission: 'READ'
        });

        res.status(201).json(share);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getShares = async (req, res) => {
    try {
        const ownerId = req.user.id;
        const shares = await Share.findAll({
            where: { owner_id: ownerId }
        });
        res.json(shares);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

exports.revokeShare = async (req, res) => {
    try {
        const ownerId = req.user.id;
        const { id } = req.params;

        const share = await Share.findOne({ where: { id, owner_id: ownerId } });
        if (!share) return res.status(404).json({ message: "Share not found" });

        await share.destroy();
        res.json({ message: "Access revoked" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
}
