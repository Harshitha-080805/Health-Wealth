const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Share = sequelize.define('Share', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
    },
    viewer_email: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            isEmail: true,
        },
    },
    resource_type: {
        type: DataTypes.ENUM('ALL', 'REPORT'),
        defaultValue: 'ALL',
    },
    resource_id: {
        type: DataTypes.UUID,
        allowNull: true, // If type is ALL, this is null
    },
    permission: {
        type: DataTypes.ENUM('READ'),
        defaultValue: 'READ',
    },
});

module.exports = Share;
