const sequelize = require('../config/database');
const User = require('./User');
const Report = require('./Report');
const Vital = require('./Vital');
const Share = require('./Share');

// Relationships

// User has many Reports
User.hasMany(Report, { foreignKey: 'user_id' });
Report.belongsTo(User, { foreignKey: 'user_id' });

// User has many Vitals
User.hasMany(Vital, { foreignKey: 'user_id' });
Vital.belongsTo(User, { foreignKey: 'user_id' });

// User has many Shares (as Owner)
User.hasMany(Share, { foreignKey: 'owner_id', as: 'SharedLinks' });
Share.belongsTo(User, { foreignKey: 'owner_id', as: 'Owner' });

module.exports = {
    sequelize,
    User,
    Report,
    Vital,
    Share,
};
