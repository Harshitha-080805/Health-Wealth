const express = require('express');
const router = express.Router();
const shareController = require('../controllers/shareController');
const authenticateToken = require('../middleware/authMiddleware');

router.post('/', authenticateToken, shareController.shareResource);
router.get('/', authenticateToken, shareController.getShares);
router.delete('/:id', authenticateToken, shareController.revokeShare);

module.exports = router;
