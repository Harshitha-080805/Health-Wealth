const express = require('express');
const router = express.Router();
const vitalController = require('../controllers/vitalController');
const authenticateToken = require('../middleware/authMiddleware');

router.get('/', authenticateToken, vitalController.getVitals);
router.post('/', authenticateToken, vitalController.addVital);
router.delete('/:id', authenticateToken, vitalController.deleteVital);

module.exports = router;
